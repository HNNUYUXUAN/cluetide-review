# ClueTide investigation

区块24106378观察到国库地址向dead转移1亿UNI。交易与回执、提案93材料支持有限治理解释；本轮Agent未读取历史供应getter，供应变化保持未知。

Coverage: complete

## Deterministic transfer facts

- 100000000 UNI; raw ERC-20 token base units: `100000000000000000000000000`; decimals: 18. [transfer:1:0xdffacec5530523a39bbb539d65518cdcb754b67369477767586f1ad66d596f14:0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e:11]

## Report quality checks

Status: no_flags_detected
Limited checks of units, attack exclusion and contract-wide burn wording in summary, claims and supported explanations; semantic support requires review, no factual verification.

## Citation structure checks

Status: needs_review
- Successful receipt or transaction evidence lacks a matching raw RPC observation.
- Successful receipt or transaction evidence lacks a matching raw RPC observation.
Bounded structural checks of claim and directed candidate-explanation references to successful Agent evidence, explanation-status bindings, Transfer links to supplied RPC observations, and receipt/transaction identity consistency. No factual verification, source authenticity, completeness, or reviewer independence is established.

## Claims and evidence

- 交易0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e在区块24106378执行了100,000,000 UNI代币从0x1a9c8182c09f50c8318d769245bea52c32be35bc到销毁地址0x000...dead的转移 [transfer:1:0xdffacec5530523a39bbb539d65518cdcb754b67369477767586f1ad66d596f14:0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e:11, derived:transfer-amounts]
- Uniswap治理提案93明确指定了向销毁地址转移100,000,000 UNI的操作，这与观察到的转移金额和地址匹配 [source:uniswap-proposal-93]
- 交易to字段为0x408ed6354d4973f66138c91495f2f2fcbd8724c3，input末32字节为0x5d，回执status为成功。执行授权和其他治理动作需另行核验。 [transaction:0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e, receipt:0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e]

## Transaction investigation scope

Selection: 选取告警引用的 Transfer 中原始金额最大的代表事件及其交易；金额相同时按 evidence_id 字典序确定代表事件。告警阈值是原始单位的工程规则，告警用于提供调查线索。
Selected transaction: 0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e
Successfully read transaction: 0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e
Other recorded transactions awaiting investigation: 
Agent 复核聚焦选定的代表交易；窗口内其余交易只记录确定性采集证据。调查完成状态依据后续交易或回执工具的成功读取记录更新。

## Explanation assessments

- governance_execution: 所选大额UNI转移与提案93记载的治理执行动作一致。 (supported)
  Supporting evidence: source:uniswap-proposal-93, transfer:1:0xdffacec5530523a39bbb539d65518cdcb754b67369477767586f1ad66d596f14:0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e:11, derived:transfer-amounts
  Counter evidence: 
  Unknowns: 未验证提案93在链上的实际投票和执行状态，仅依赖治理来源描述; 未检查发送方地址0x1a9c8182c09f50c8318d769245bea52c32be35bc是否为治理合约或授权执行者
  Checks: 确认转移金额100,000,000 UNI与提案93指定金额匹配; 确认目标地址为销毁地址0x000...dead与提案指定一致; 确认交易执行成功且来自合约调用
- supply_decrease: 向销毁地址转移100,000,000 UNI可能导致UNI代币总供应量减少 (unknown)
  Supporting evidence: 
  Counter evidence: 
  Unknowns: 未比较转移前后两个历史区块的代币总供应量状态; 未确认销毁地址的余额是否永久锁定且不可提取
  Checks: 需要读取区块24106377和24106379的token_state以比较total_supply_raw变化; 需要确认销毁地址0x000...dead的余额是否计入总供应量计算

Execution status: completed
Stop reason: None

## Limits

- 调查受限于4次模型请求预算，无法获取转移前后的代币状态进行比较
- 未验证治理提案93在链上的实际执行授权和投票结果
- 未检查发送方地址0x1a9c8182c09f50c8318d769245bea52c32be35bc的权限和角色
- 治理来源文本为外部快照，未独立验证其完整性和准确性
- 未确认销毁地址转移是否确实导致总供应量永久减少
- 调查范围仅限于观察到的单笔转移，未检查同一交易中的其他日志（如第二个Transfer事件）
- Hashes establish byte integrity, not factual truth.
- Local roles and browser profiles are controlled demo roles; independent review has not been established.

## Reviewer-driven corrections

- 将成功回执、治理解释与授权范围分开，保留未核验事项。
