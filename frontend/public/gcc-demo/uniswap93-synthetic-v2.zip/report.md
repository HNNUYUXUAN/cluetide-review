# Uniswap 93 synthetic demonstration

Revision: 2

This report is a deterministic local fixture built from the bundled public RPC snapshot.
Its interpretation is synthetic. Model requests, network reads, signing and broadcasts during generation: 0.

The bundled snapshot records one outgoing UNI transfer to the dead address. This synthetic report leaves its causal explanation for review.

## Evidence claims

- The local adapter returned a confirmed receipt and transaction for the selected transfer.
  Evidence: receipt:0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e, transaction:0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e
- One outgoing Transfer records 100000000000000000000000000 raw token units to 0x000000000000000000000000000000000000dead. This Transfer alone establishes no totalSupply change.
  Evidence: receipt:0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e
- The bundled project summary points to Uniswap proposal 93 as governance context.
  Evidence: source:uniswap-proposal-93
- The selected receipt has a successful execution status in the public snapshot.
  Evidence: receipt:0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e

## Explanation assessments

- confirmed_execution: The selected transaction executed successfully (supported)
  Supporting evidence: receipt:0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e, transaction:0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e
  Counter evidence: 
  Unknowns: 
  Checks: Compare the confirmed receipt status and transaction identity in the captured snapshot.
- supply_decrease: A net decrease in the totalSupply getter across the captured block pair (refuted)
  Supporting evidence: 
  Counter evidence: state:0x1f9840a85d5af5bf1d1762f925bdaddc4201f984:24106377, state:0x1f9840a85d5af5bf1d1762f925bdaddc4201f984:24106378
  Unknowns: 
  Checks: Compare every raw integer digit of the two historical totalSupply getter observations.
- event_explanation: Cause of the selected transfer (unknown)
  Supporting evidence: 
  Counter evidence: 
  Unknowns: The synthetic fixture does not establish the event's causal explanation.
  Checks: Read the captured receipt, transaction and attributed context summary.

## Limits

- The explanation is a deterministic synthetic fixture, with zero model requests.
- RPC data and project source summaries require independent source review.
- A dead-address transfer alone does not establish a totalSupply decrease.
- SHA-256 commitments verify artifact bytes, not factual truth.
- Local review roles are controlled demonstration roles.

## Local correction

- Clarify that the transfer evidence alone establishes no totalSupply change.
