# Euler DAI 公开回放 v2

合成报告与复核示例；公开观察取得于 2026-10-07 UTC。

本窗口记录 Euler 主体的 DAI 流入与流出。入减出只表示所选窗口的净 Transfer 流，不能直接用作事件损失。

窗口：16817995–16817997。

- Euler Labs: https://www.euler.finance/blog/war-peace-behind-the-scenes-of-eulers-240m-exploit-recovery
- Omniscia: https://medium.com/@omniscia.io/euler-finance-incident-post-mortem-1ce077c28454
- Euler legacy GitHub organization: https://github.com/euler-legacy-xyz/euler-contracts/blob/fa9398728165676a5666939d8c34a7578d8e1919/contracts/modules/EToken.sol#L356-L386
- Euler Finance documentation: https://docs-v1.euler.finance/euler-protocol/addresses

SHA-256 校验文件字节，不能证明事实真实性。
