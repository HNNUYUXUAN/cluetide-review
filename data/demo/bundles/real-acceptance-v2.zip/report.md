# ClueTide investigation

公开回执、交易调用和治理材料支持 Uniswap 提案 93 的执行解释：Timelock 向 dead 地址转出 1 亿 UNI。转账本身不证明 totalSupply 减少；本范围证据也不足以排除所有攻击或异常。

Coverage: complete

## Deterministic transfer facts

- 100000000 UNI; raw ERC-20 token base units: `100000000000000000000000000`; decimals: 18. [transfer:1:0xdffacec5530523a39bbb539d65518cdcb754b67369477767586f1ad66d596f14:0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e:11]

## Report quality checks

Status: no_flags_detected
Limited checks of ERC-20 wei wording and categorical attack exclusion in summary/claims; no factual verification.

## Claims and evidence

- 交易0x091f...是对Uniswap GovernorBravo合约0x408ED6354d4973f66138C91495F2f2FCbd8724C3的调用，函数选择器为execute(uint256)，参数0x5d对应提案ID 93 [transaction:0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e]
- 回执记录 UNI 从 Timelock 地址转向 0x000000000000000000000000000000000000dead；原始 uint256 数量为 100000000000000000000000000，以 18 位小数表示 100,000,000 UNI。 [receipt:0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e]
- Uniswap治理提案93（UNIfication）包含UNI.transfer(0xdead, 100_000_000 ether)操作，且提案状态显示为已执行 [source:uniswap-proposal-93]
- Timelock地址0x1a9C8182C09F50C8318d769245beA52c32BE35BC和GovernorBravo地址0x408ED6354d4973f66138C91495F2f2FCbd8724C3与Uniswap官方文档中公布的治理合约地址一致 [source:uniswap-governance-contracts]
- UNI代币的transfer函数流程会发出Transfer事件但不更新totalSupply；totalSupply变化需要独立验证 [source:uniswap-uni-source]

## Limits

- 未调用代币状态读取功能来验证totalSupply在事件前后是否实际减少
- 未验证提案93的投票状态和时间锁延迟期，仅依据治理页面显示的"已执行"状态
- 未检查Timelock对GovernorBravo的授权关系或代理执行模式
- 未分析交易中可能的其他治理操作（提案93包含八个调用）
- 证据基于第三方资料的可信快照，未进行链上验证的独立交叉核对
- 调查范围受限于from_block和to_block边界，未检查更广泛的上下文
- 无法确认UNI持有者投票参与度或提案合法性，仅依赖可见的治理流程
- Hashes establish byte integrity, not factual truth.
- Local roles and browser profiles are controlled demo roles; independent review has not been established.

## Reviewer-driven corrections

- 根据复核意见更正 UNI raw units 与攻击判断边界；保留原始模型 v1。
