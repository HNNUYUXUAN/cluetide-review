# ClueTide investigation

在区块 24106378，一笔交易从 Uniswap 国库时间锁向销毁地址转移了 100,000,000 UNI。该转移与治理提案 93 的执行相符，但 ERC-20 总供应量在同一区块前后未发生变化，表明该代币合约未实现销毁机制。

Coverage: complete

## Deterministic transfer facts

- 100000000 UNI; raw ERC-20 token base units: `100000000000000000000000000`; decimals: 18. [transfer:1:0xdffacec5530523a39bbb539d65518cdcb754b67369477767586f1ad66d596f14:0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e:11]

## Report quality checks

Status: needs_review
- A bounded supply comparison needs complete implementation evidence before supporting a contract-wide burn claim.
Limited checks of units, attack exclusion and contract-wide burn wording in summary, claims and supported explanations; semantic support requires review, no factual verification.

## Citation structure checks

Status: needs_review
- Successful receipt or transaction evidence lacks a matching raw RPC observation.
- Successful receipt or transaction evidence lacks a matching raw RPC observation.
Bounded structural checks of claim and directed candidate-explanation references to successful Agent evidence, explanation-status bindings, Transfer links to supplied RPC observations, and receipt/transaction identity consistency. No factual verification, source authenticity, completeness, or reviewer independence is established.

## Claims and evidence

- 交易 0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e 在区块 24106378 执行，从地址 0x1a9c8182c09f50c8318d769245bea52c32be35bc（Uniswap 国库时间锁）向销毁地址 0x000000000000000000000000000000000000dead 转移了 100,000,000 UNI（原始金额 100000000000000000000000000）。 [transfer:1:0xdffacec5530523a39bbb539d65518cdcb754b67369477767586f1ad66d596f14:0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e:11, derived:transfer-amounts]
- 该交易由 GovernorBravo 合约（0x408ed6354d4973f66138c91495f2f2fcbd8724c3）调用，输入数据包含提案 ID 93，符合 Uniswap 治理技术参考中记载的合约地址。 [transaction:0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e, source:uniswap-governance-contracts]
- UNI 代币在区块 24106377 和 24106378 的总供应量均为 1,000,000,000,000,000,000,000,000,000（原始字符串），表明 ERC-20 totalSupply 在该转移事件前后未发生变化。 [state:0x1f9840a85d5af5bf1d1762f925bdaddc4201f984:24106377, state:0x1f9840a85d5af5bf1d1762f925bdaddc4201f984:24106378]

## Transaction investigation scope

Selection: 选取告警引用的 Transfer 中原始金额最大的代表事件及其交易；金额相同时按 evidence_id 字典序确定代表事件。告警阈值是原始单位的工程规则，告警用于提供调查线索。
Selected transaction: 0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e
Successfully read transaction: 0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e
Other recorded transactions awaiting investigation: 
Agent 复核聚焦选定的代表交易；窗口内其余交易只记录确定性采集证据。调查完成状态依据后续交易或回执工具的成功读取记录更新。

## Explanation assessments

- governance_execution: 该转移是 Uniswap 治理提案 93 的预期执行，该提案指定从国库向销毁地址转移 100,000,000 UNI，作为统一化计划的一部分。 (supported)
  Supporting evidence: source:uniswap-proposal-93, source:uniswap-unification-blog, transaction:0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e, transfer:1:0xdffacec5530523a39bbb539d65518cdcb754b67369477767586f1ad66d596f14:0x091f0083242a777d55821c1189e568d6d033d9da501b75087dc736fa143d2c1e:11
  Counter evidence: 
  Unknowns: 
  Checks: 治理提案 93 明确指定了 transfer(0xdead, 100_000_000 ether) 调用。; 交易输入数据包含提案 ID 93（0x5d），且调用目标为 GovernorBravo 合约。; 转移金额、发送方（国库时间锁）和接收方（销毁地址）与提案描述一致。
- supply_decrease: 该转移导致 UNI 代币总供应量减少。 (refuted)
  Supporting evidence: 
  Counter evidence: state:0x1f9840a85d5af5bf1d1762f925bdaddc4201f984:24106377, state:0x1f9840a85d5af5bf1d1762f925bdaddc4201f984:24106378
  Unknowns: 
  Checks: 比较区块 24106377（转移前）和 24106378（转移所在区块）的 totalSupply 原始值，两者均为 1000000000000000000000000000。; ERC-20 标准中，向销毁地址转移不会自动减少 totalSupply，除非合约实现特定的销毁机制。

Execution status: completed
Stop reason: None

## Limits

- 调查范围仅限于区块 24106368 至 24106388 内的转移事件，未检查其他可能相关的交易或代币余额变化。
- 治理来源为公开网页摘录，未进行独立验证其完整性和权威性。
- 未检查发送方（国库时间锁）在转移前的代币余额，无法确认转移是否来自授权持仓。
- 未分析交易中的其他日志（如 Approval 事件），可能存在额外的治理操作。
- 总供应量比较仅基于两个特定区块的快照，未排除中间区块的临时变化可能性。
- 证据哈希仅保证摘录文件的完整性，不保证来源内容的真实性。
- Hashes establish byte integrity, not factual truth.
- Local roles and browser profiles are controlled demo roles; independent review has not been established.
